import javax.swing.*;

public class GUIRunner {
    public static void main(String[] args) {
        //AddCustomerFrame c = new AddCustomerFrame();
       // AddBookingFrame addBookingFrame = new AddBookingFrame();
       // addBookingFrame.setVisible(true);
          CustomerMainMenu c = new CustomerMainMenu();
       // AddEmployeeFrame e = new AddEmployeeFrame();
       // CustomerFrame c = new CustomerFrame();
      //  UpdateBookingFrame u = new UpdateBookingFrame();
       // ManagerFrame f = new ManagerFrame();
    }
}
